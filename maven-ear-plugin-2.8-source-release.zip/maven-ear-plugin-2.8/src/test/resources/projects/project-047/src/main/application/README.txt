#####
#
# ${application.name} ${project.version}
#
#####

Bla bla bla bla bla.

Enjoy!


--The Maven team