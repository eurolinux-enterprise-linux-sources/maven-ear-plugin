#####
#
# ${application.name} ${project.version} (Build ${application.build})
#
#####

Bla bla bla bla bla.

This property will not be filtered ${application.unknown}.

Enjoy!


--The Maven team