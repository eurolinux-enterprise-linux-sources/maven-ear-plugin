#####
#
# ${application.name} ${project.version}
#
#####

Bla bla bla bla bla.

This property will not be filtered \${application.name}.

Enjoy!


--The Maven team